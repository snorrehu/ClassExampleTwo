public class CreditCardPayment implements Payment{

    int amount;

    @Override
    public int calcAmount(int amount){
        return 0;


    }

    public boolean authorize(){
        return true;
    }

}