

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Sale extends JFrame {

    public JButton cashBut, credBut;
    public JTextArea textPrice, textOut, cashPay;
    public JLabel labelPrice, labelOut, labelCash, labelPayment;

    public static void main(String[] args) {
        Sale ex = new Sale();
    }

    public Sale() {

        this.setTitle("Example");
        this.setSize(300, 400);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLayout(new BorderLayout());

        ListenForButton lForButton = new ListenForButton();
        JPanel numberPanel = new JPanel();
        JPanel inputPanel = new JPanel();
        JPanel upperPanel = new JPanel();

        numberPanel.setLayout(new GridLayout(1, 2));
        inputPanel.setLayout(new GridLayout(6, 1));
        upperPanel.setLayout(new GridLayout(1,1));

        textPrice = new JTextArea("0");
        textPrice.setPreferredSize(new Dimension(100, 30));

        textOut = new JTextArea("0");
        textOut.setPreferredSize(new Dimension(100, 30));

        cashPay = new JTextArea("0");
        cashPay.setPreferredSize(new Dimension(100,30));

        labelPrice = new JLabel("Price of item");
        labelCash = new JLabel("Amount of cash given");
        labelOut = new JLabel("Output");
        labelPayment = new JLabel("Please choose your payment method");

        cashBut = new JButton("cash");
        cashBut.setPreferredSize(new Dimension(150,40));
        cashBut.addActionListener(lForButton);

        credBut = new JButton("credit");
        credBut.setPreferredSize(new Dimension(150, 40));
        credBut.addActionListener(lForButton);

        upperPanel.add(labelPayment);
        numberPanel.add(cashBut);
        numberPanel.add(credBut);

        inputPanel.add(labelPrice);
        inputPanel.add(textPrice);
        inputPanel.add(labelCash);
        inputPanel.add(cashPay);
        inputPanel.add(labelOut);
        inputPanel.add(textOut);

        this.add(upperPanel,BorderLayout.NORTH);
        this.add(inputPanel, BorderLayout.SOUTH);
        this.add(numberPanel, BorderLayout.EAST);

        setVisible(true);
    }

    Payment newPayment;

    public class ListenForButton implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {

            String input = textPrice.getText();
            String myBack = cashPay.getText();
            int inputInt = Integer.parseInt(input);
            int myTender = Integer.parseInt(myBack);


            if(e.getSource() == cashBut){
                newPayment = new CashPayment(inputInt, myTender);
                if(newPayment.calcAmount(inputInt) >= inputInt){
                    textOut.setText("" + newPayment.calcAmount(inputInt) + " golden coins returned");
                } else {
                    textOut.setText("You require " + (inputInt-myTender) + " more minerals");
                }
            }
            if(e.getSource() == credBut){

                newPayment = new CreditCardPayment();
                    newPayment.calcAmount(inputInt);
                    if(newPayment instanceof CreditCardPayment){
                        if(((CreditCardPayment) newPayment).authorize()){
                         textOut.setText("Payment authorized");
                        }
                        else {
                            textOut.setText("This should never happen");
                        }
                    }

            }

        }
    }
}





