interface Payment{

    int calcAmount(int amount);
}