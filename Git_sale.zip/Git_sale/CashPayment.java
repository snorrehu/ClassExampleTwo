public class CashPayment implements Payment{


    int amount;
    int price;

    public CashPayment(int amount, int price){
        this.amount = amount;
        this.price = price;
    }

    @Override
    public int calcAmount(int amount){
        this.price = price;
        this.amount = amount;
        int change = price - amount;
        return change;
    }
}