package com.class2;

public class Sale {

    double amount;

    Payment newPayment;

    //Defines an Instance of either CCPayment or CashPayment in class constructor

    public Sale(double amount, Payment newPayment) {
        this.amount = amount;
        this.newPayment = newPayment;
    }

    public void pay() {

        newPayment.calcAmount();

    }







}

