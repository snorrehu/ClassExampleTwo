package com.class2;

public interface Payment{


    void calcAmount();
}
