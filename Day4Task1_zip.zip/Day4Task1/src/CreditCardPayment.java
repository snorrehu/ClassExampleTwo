package com.class2;

import javax.swing.*;

public class CreditCardPayment implements Payment {

    private double amount;

    public CreditCardPayment(double amount){
        this.amount = amount;
    }


    public void calcAmount() {

        if(!autorize()) {
            JOptionPane.showMessageDialog(null, "Payment failed" );
        } else {
            JOptionPane.showMessageDialog(null, amount + " paid with card" );
        }
    }



    public boolean autorize() {
        double failrate = 0.1;

        if (failrate >= Math.random()) {
            return false;
        }
        return true;
    }
}
