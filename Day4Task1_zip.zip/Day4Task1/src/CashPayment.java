package com.class2;

import javax.swing.*;

public class CashPayment implements Payment {

    private double amount;
    private double amountTendered;


    public CashPayment(double amount, double amountTendered) {
        this.amount = amount;
        this.amountTendered = amountTendered;

    }




    public void calcAmount() {
        JOptionPane.showMessageDialog(null, "Total price: " + amount + "\nAmount paid: " + amountTendered
                                        + "\nChange given: " + (amountTendered - amount));
    }
}
