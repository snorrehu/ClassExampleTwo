package com.class2;

import javax.swing.*;
import java.awt.*;

import javax.swing.JOptionPane;

public class Main{

        public static void main(String[] args) {

        Sale sale;

        String[] options1 = { "Cash Payment", "Card Payment"};

        double amount,tendered;

        JPanel panel = new JPanel();
        JTextField textField = new JTextField(10);
        panel.add(textField);

        int option = JOptionPane.showOptionDialog(null, panel, "Enter total price",
                JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE,
                null, options1, null);

        if (option == JOptionPane.YES_OPTION){ //Cash Option


            amount = Integer.parseInt(textField.getText());
            textField.setText("");

            JOptionPane.showMessageDialog(null, panel, "Enter amount to pay in cash", JOptionPane.OK_OPTION);

            tendered = Integer.parseInt(textField.getText());

            // Calling the sale constructor, creating an instance of CashPayment -> Sale(double amount, Payment newPayment)
            sale = new Sale(amount, new CashPayment(amount, tendered));
            sale.pay();
        }



        if (option == JOptionPane.NO_OPTION){ // Card Option

            amount = Integer.parseInt(textField.getText());

            // Calling the sale constructor, creating an instance of CreditCardPayment -> Sale(double amount, Payment newPayment)
            sale = new Sale(amount, new CreditCardPayment(amount));
            sale.pay();

        }

    }
}
